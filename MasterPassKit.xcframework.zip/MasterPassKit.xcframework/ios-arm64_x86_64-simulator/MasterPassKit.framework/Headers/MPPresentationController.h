//
//  MPPresentationController.h
//  MasterPassKit
//
//  Created by Ferdie Danzfuss on 2016/03/29.
//  Copyright © 2016 Mobilica (Pty) Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MPPresentationController : UIPresentationController

@property UIView *dimmingView;



@end
